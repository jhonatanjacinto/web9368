const moduloSync = (function() {

    const badge = document.querySelector('.badge-info');

    carregarItens();
    async function carregarItens()
    {
        // PARTE 1
    }

    async function sincronizar()
    {
        // PARTE 2
    }

    return {
        sincronizar
    }

})();